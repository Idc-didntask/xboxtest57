# OriginsPE project

This project is directly derived from the Origins mod which can be downloaded [here](https://www.curseforge.com/minecraft/mc-mods/origins).

(c) [@apace100](https://www.curseforge.com/members/apace100/) | Copyright under MIT LICENSE | 2021
(c) [@r4isen1920](https://twitter.com/r4isen1920) | Copyright under MIT LICENSE | 2022

## License & Usage
You can use what you learn from this pack onto your own creation or for your own use. Putting my name on the 'credits' section or giving me some exposure to say the least is appreciated! Check the `LICENSE.md` file to learn more.

## Distribution
While otherwise told by the license, I still do not condone sharing my content without leaving exposure to the original creator. I, too, have spent my valuable time doing all of this work - and should you redistribute my content (e.g. re-uploading it as your own), you'll be sure to know that I will do my best to take it down!

## Contributors
I have made a list here to thank these people who have made this add-on possible:
- [@CrisXolt](https://twitter.com/CrisXolt)
- [@JoshMC](https://twitter.com/RealJoshMC)
- @Veka
- [@LukasPAH](https://twitter.com/LukasPAH)
- [@GoggledGecko](https://twitter.com/TheGoggledGecko)
- [@SirLich](https://twitter.com/Sir_Lich)

## Acknowledgement
These people have, in addition, gave me inspiration to be able to do things for this add-on:
- [@ShadowSharkPVP](https://twitter.com/ShadowSharkPVP)
- [@lammas123](https://mcpedl.com/user/lammas123/)